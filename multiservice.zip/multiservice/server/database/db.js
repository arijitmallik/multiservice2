import mongoose from "mongoose";

const connect = async (username, password) => {
  const URL = `mongodb+srv://${username}:${password}@cluster0.cfk09sy.mongodb.net/?retryWrites=true&w=majority`;
  try {
    await mongoose.connect(URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log("DB Connection Successful");
  } catch (error) {
    console.log("Error While Connecting to Database", error);
  }
};

export default connect;

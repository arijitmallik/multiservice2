import express from "express";
import dotenv from 'dotenv';
import cors from 'cors';
import bodyParser from 'body-parser';

const app = express();
const PORT = 8000;

import Connection from "./database/db.js";
import Routes from './route/router.js';
import Reg from "./schema/register_schema.js";
import login from "./schema/login-schema.js";
dotenv.config();

const username = process.env.DB_USERNAME;
const password = process.env.DB_PASSWORD;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(cors());

Connection(username, password);

app.use('/upload', express.static('uploads'));

app.use('/', Routes);
app.use("/", login);
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});

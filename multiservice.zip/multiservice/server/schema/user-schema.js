import mongoose from "mongoose";

const UserSchema = mongoose.Schema({
    name:String,
    email: String,
    mobile: String,
    gender: String,
    service: String,
    your_time: String,
    state: String,
    city: String,
    pincode: String,
    address: String
     
  
});

const User = mongoose.model('multiservice', UserSchema);

export default User;

import mongoose from "mongoose";

const loginSchema = mongoose.Schema({
    email: String,
    password: String,
    
});

const logins = mongoose.model('login',loginSchema);

export default logins;

import mongoose from "mongoose";

const RegSchema = mongoose.Schema({
    name: String,
    email: String,
    password: String,
    conpassword: String
});

const Reg = mongoose.model('reg',RegSchema);

export default Reg;

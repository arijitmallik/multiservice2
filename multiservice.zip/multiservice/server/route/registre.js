import express from "express";
import multer from "multer";
import Reg from "../schema/register_schema";

const router = express.Router();

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads');
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  }
});

const upload = multer({ storage: storage });

router.post('/add', upload.single('image'), async (req, res) => {
  try {
    const reg = new Reg();
    reg.name = req.body.name;
    reg.email = req.body.email;
    reg.password = req.body.password;
    reg.conpassword = req.body.conpassword;

    await reg.save();

    res.status(201).json('success');
    console.log("Received");
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});

export default router;

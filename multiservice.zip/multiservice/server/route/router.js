import express from "express";
import multer from "multer";
import User from "../schema/user-schema.js";

const router = express.Router();

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads');
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname);
    }
});

const upload = multer({ storage: storage });

router.post('/add', upload.single('image'), async (req, res) => {
    try {
        const user = new User();
        user.name = req.body.name;
        user.mobile = req.body.mobile;
        user.email = req.body.email;
        user.gender = req.body.gender;
        user.service = req.body.service;
        user.your_time = req.body.your_time;
        user.address = req.body.address;
        user.state = req.body.state;
        user.city = req.body.city;
        user.pincode = req.body.pincode;

        await user.save();

        res.status(201).json('success');
        alert("recived");
    } catch (error) {
        res.status(500).json({ error: 'An error occurred' });
    }
});

export default router;

import express from "express";
import multer from "multer";
import login from "../schema/login-schema";
const router = express.Router();

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads');
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname);
    }
});

const upload = multer({ storage: storage });

router.post('/add', upload.single('image'), async (req, res) => {
    try {
        const login2 = new login();
      
        user.email = req.body.email;
     
        user.password = req.body.password;

        await login2.save();

        res.status(201).json('success');
        alert("recived");
    } catch (error) {
        res.status(500).json({ error: 'An error occurred' });
    }
});

export default router;

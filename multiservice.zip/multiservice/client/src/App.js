import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// import logo from './logo.svg';
import './App.css';
import NavBar from './components/NavBar';
import "./assets/lib/animate/animate.min.css"
import "./assets/lib/owlcarousel/assets/owl.carousel.min.css" 
import "./assets/lib/lightbox/css/lightbox.min.css" 
import "./assets/css/bootstrap.min.css" 
import "./assets/css/style.css"
import Service from './components/Service';
import Footer from './components/Footer';
import Home from './components/Home';
import Contact from './components/Contact';
import Register from './components/Register';
import Login from './components/Login';
import ServiceRegister from './components/ServiceRegister';
import Team from './components/Team';
import About from './components/About';
import ServiceInsider from './components/ServiceInsider';

function App() {
  return (
    <>
      <Router>
      <NavBar />
       <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/service" element={<Service />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/team" element={<Team />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register_ Business" element={<ServiceRegister />} />
        <Route path="/ServiceInsider" element={<ServiceInsider />} />
       
        
      </Routes>
    </Router>  
    
    <Footer/>
    </>
    
  );
}

export default App;

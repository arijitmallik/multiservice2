import React, { useState } from 'react';
import { useToast } from '@chakra-ui/react';
import { Link } from 'react-router-dom'; // Fix the import statement
import Carousel1 from '../assets/img/carousel-1.jpg';
import { addUser } from '../Service/api';
import Register from './Register';

const Login = () => {
  const [user, setUser] = useState({
    name: '',
    password: '',
  });

  const toast = useToast();

  const onValueChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const submitData = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('name', user.name);
    formData.append('password', user.password);

    try {
      const response = await addUser(formData);
      if (response.status === 201) {
        toast({
          title: 'Account created.',
          description: "We've created your account for you.",
          status: 'success',
          duration: 9000,
          isClosable: true,
          position: 'top',
        });
      } else {
        console.log('Error occurred while adding user.');
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      {/* Login Start */}
      <div className="container-fluid bg-light overflow-hidden px-lg-0">
        <div className="container contact px-lg-0">
          <div className="row g-0 mx-lg-0">
            <div className="col-lg-6 contact-text py-5 wow fadeIn" data-wow-delay="0.5s">
              <div className="p-lg-5 ps-lg-0">
                <div className="section-title text-start">
                  <h1 className="display-5 mb-4">Login</h1>
                </div>

                <form>
                  <div className="row g-3">
                    <div className="col-8">
                      <div className="form-floating">
                        <input
                          type="email"
                          name="name"
                          className="form-control"
                          id="email"
                          onChange={onValueChange}
                          placeholder="Your Email"
                        />
                        <label htmlFor="email">Your Email</label>
                      </div>
                    </div>
                    <div className="col-8">
                      <div className="form-floating">
                        <input
                          type="password"
                          name="password"
                          className="form-control"
                          id="Password"
                          onChange={onValueChange}
                          placeholder="Password"
                        />
                        <label htmlFor="subject">Password</label>
                      </div>
                    </div>

                    <Link to="/Register">Don't have an account</Link>

                    <div className="col-8">
                      <button className="btn btn-primary w-100 py-3" type="submit">
                        Login
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <div className="col-lg-6 pe-lg-0" style={{ minHeight: '400px' }}>
              <div className="position-relative h-100">
                <img
                  className="position-absolute w-100 h-100"
                  onClick={submitData}
                  style={{ objectFit: 'cover' }}
                  src={Carousel1}
                  alt="imgnotfound"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Login End */}
    </>
  );
};

export default Login;

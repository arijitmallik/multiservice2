import React, { useState } from 'react';
import { useToast } from '@chakra-ui/react';
import Quote from '../assets/img/carousel-4.jpg';
import { addUser } from '../Service/api';

const ServiceRegister = () => {
  const [user, setUser] = useState({
    name: '',
    email: '',
    mobile: '',
    gender: '',
    service: '',
    your_time: '',
    state: '',
    city: '',
    pincode: '',
    address: ''
  });

  const toast = useToast();

  const onValueChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const submitData = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('name', user.name);
    formData.append('email', user.email);
    formData.append('gender', user.gender);
    formData.append('service', user.service);
    formData.append('your_time', user.your_time);
    formData.append('state', user.state);
    formData.append('city', user.city);
    formData.append('pincode', user.pincode);
    formData.append('address', user.address);

    try {
      const response = await addUser(formData);
      if (response.status === 201) {
        toast({
          title: 'Account created.',
          description: "We've created your account for you.",
          status: 'success',
          duration: 9000,
          isClosable: true,
          position: 'top'
        });
      } else {
        console.log('Error occurred while adding user.');
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      {/* ServiceRegister Start */}
      <div className="container-fluid bg-light overflow-hidden px-lg-0">
        <div className="container quote px-lg-0">
          <div className="row g-0 mx-lg-0">
            <div className="col-lg-6 ps-lg-0" style={{ minHeight: '400px' }}>
              <div className="position-relative h-100">
                <img className="position-absolute img-fluid w-100 h-100" src={Quote} style={{ objectFit: 'cover' }} alt="" />
              </div>
            </div>
            <div className="col-lg-6 quote-text py-5 wow fadeIn" data-wow-delay="0.5s">
              <div className="p-lg-5 pe-lg-0">
                <div className="bg-primary mb-3" style={{ width: '60px', height: '2px' }}></div>
                <h1 className="display-5 mb-5">Register Your Service</h1>
                <p className="mb-4 pb-2">Register your Service with us to expand your business, reach to many people with your work and our service</p>
                <form onSubmit={submitData}>
                  <div className="row g-3">
                    <div className="col-12 col-sm-6">
                      <input type="text" name="name" onChange={onValueChange} className="form-control border-0" placeholder="Your Name" style={{ height: '55px' }} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <input type="email" name="email" onChange={onValueChange} className="form-control border-0" placeholder="Your Email" style={{ height: '55px' }} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <input type="text" name="mobile" onChange={onValueChange} className="form-control border-0" placeholder="Your Mobile" style={{ height: '55px' }} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <select className="form-select border-0" onChange={onValueChange} style={{ height: '55px' }} name="gender">
                        <option defaultValue>Your Gender</option>
                        <option value="1">Male</option>
                        <option value="2">Female</option>
                        <option value="3">Other</option>
                      </select>
                    </div>
                    <div className="col-12 col-sm-6">
                      <input type="text" name="service" onChange={onValueChange} className="form-control border-0" placeholder="Your Service Type" style={{ height: '55px' }} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <input type="text" name="your_time" onChange={onValueChange} className="form-control border-0" placeholder="Your Service Time" style={{ height: '55px' }} />
                    </div>
                    <div className="col-12 col-sm-4">
                      <input type="text" name="state" onChange={onValueChange} className="form-control border-0" placeholder="Your State" style={{ height: '55px' }} />
                    </div>
                    <div className="col-12 col-sm-4">
                      <input type="text" name="city" onChange={onValueChange} className="form-control border-0" placeholder="Your City" style={{ height: '55px' }} />
                    </div>
                    <div className="col-12 col-sm-4">
                      <input type="text" name="pincode" onChange={onValueChange} className="form-control border-0" placeholder="Your Pincode" style={{ height: '55px' }} />
                    </div>
                    <div className="col-12">
                      <textarea className="form-control border-0" name="address" onChange={onValueChange} placeholder="Your full address with landmark of your business"></textarea>
                    </div>
                    <div className="col-12">
                      <button className="btn btn-primary w-100 py-3" onClick={submitData}>Register Your Service</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* ServiceRegister End */}
    </>
  );
};

export default ServiceRegister;

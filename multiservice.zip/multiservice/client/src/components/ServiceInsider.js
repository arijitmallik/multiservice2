import React from 'react';
import cctv1 from '../assets/img/cctv1.jpeg';
import cctv2 from '../assets/img/cctv2.jpg';
import cctv3  from '../assets/img/cctv3.jpeg';
import cctv4 from '../assets/img/cctv4.jpeg';

const ServiceInsider = () => {
  return (
    <>
      <div className="container-xxl py-5">
        <div className="container">
          <div className="text-center wow fadeInUp" data-wow-delay="0.1s">
            <div className="bg-primary mb-3 mx-auto" style={{ width: '60px', imgheight: '2px' }}></div>
            <h1 className="display-5 mb-5">Service Insider</h1>
          </div>
          <div className="row g-4">
            <div className="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
              <div className="team-item">
                <div className="overflow-hidden position-relative">
                  <img className="img-fluid" src={cctv1} alt="" />
                </div>
                <div className="text-center p-4">
                  <h5 className="mb-0">Sun CCTV Corner</h5>
                  <p>Here we setup cctv for you .</p>
                  <p>call - 9983343433</p>
                  <p>Address - Haripal ,near Haripal police station </p>
                </div>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
              <div className="team-item">
                <div className="overflow-hidden position-relative">
                  <img className="img-fluid" src={cctv2} alt="" />
                </div>
                <div className="text-center p-4">
                  <h5 className="mb-0">Mukesh computer</h5>
                  <p>Best CCTV for your home, office</p>
                  <p>call - 9983343433</p>
                  <p>Address - Haripal, near Haripal police station</p>
                </div>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
              <div className="team-item">
                <div className="overflow-hidden position-relative">
                  <img className="img-fluid" src={cctv3} alt="" />
                </div>
                <div className="text-center p-4">
                  <h5 className="mb-0">Google digital Merket</h5>
                  <p>Affordable and high-quality CCTV are available</p>
                  <p>call - 9983343433</p>
                  <p>Address - Haripal, near Haripal police station</p>
                </div>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
              <div className="team-item">
                <div className="overflow-hidden position-relative">
                  <img className="img-fluid" src={cctv4} alt="" />
                </div>
                <div className="text-center p-4">
                  <h5 className="mb-0">Prince Computer</h5>
                  <p>Here we provide the cheapest and best CCTV</p>
                  <p>call - 9983343433</p>
                  <p>Address - Haripal, near Haripal police station</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ServiceInsider;

import react from 'react';
import Team1 from '../assets/img/team-1.jpg'
import Team2 from '../assets/img/team-2.jpg'
import Team3 from '../assets/img/team-3.jpg'
import Team4 from '../assets/img/team-4.jpg'



const Team=()=>{
    return(
        <>
        <div className="container-xxl py-5">
        <div className="container">
            <div className="text-center wow fadeInUp" data-wow-delay="0.1s">
                <div className="bg-primary mb-3 mx-auto" style={{width: '60px' ,imgheight: '2px'}}></div>
                <h1 className="display-5 mb-5">Team Members</h1>
            </div>
            <div className="row g-4">
                <div className="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div className="team-item">
                        <div className="overflow-hidden position-relative">
                            <img className="img-fluid" src={Team1} alt=""/>
                        </div>
                        <div className="text-center p-4">
                            <h5 className="mb-0">Ayan Mandal</h5>
                            <span className="text-primary">Designation</span>
                        </div>
                    </div>
                </div>
                <div className="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div className="team-item">
                        <div className="overflow-hidden position-relative">
                            <img className="img-fluid" src={Team2} alt=""/>
                        </div>
                        <div className="text-center p-4">
                            <h5 className="mb-0">Arijit Malik</h5>
                            <span className="text-primary">Designation</span>
                        </div>
                    </div>
                </div>
                <div className="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div className="team-item">
                        <div className="overflow-hidden position-relative">
                            <img className="img-fluid" src={Team3} alt=""/>
                        </div>
                        <div className="text-center p-4">
                            <h5 className="mb-0">Priyanka Ghosh</h5>
                            <span className="text-primary">Designation</span>
                        </div>
                    </div>
                </div>
                <div className="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                    <div className="team-item">
                        <div className="overflow-hidden position-relative">
                            <img className="img-fluid" src={Team4} alt=""/>
                        </div>
                        <div className="text-center p-4">
                            <h5 className="mb-0">Beauti Dholey</h5>
                            <span className="text-primary">Designation</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
        </>
    );

}
export default Team;
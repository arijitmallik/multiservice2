import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Carousel1 from '../assets/img/carousel-1.jpg';
// import Login from './Login';
import { addUser } from '../Service/api';
import { useToast } from '@chakra-ui/react';

const Register = () => {
    const [user, setUser] = useState({
        name: '',
        email: '',
        password:'',
        ConPassword:''
      });
    
      const toast = useToast();
      const onValueChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
      };
    
      const submitData = async (e) => {
        e.preventDefault();
    
        const formData = new FormData();
        formData.append('name', user.name);
        formData.append('email', user.email);
        formData.append('gender', user.password);
        formData.append('service', user.conpassowrd);
        
    
        try {
          const response = await addUser(formData);
          if (response.status === 201) {
            toast({
              title: 'Account created.',
              description: "We've created your account for you.",
              status: 'success',
              duration: 9000,
              isClosable: true,
              position: 'top'
            });
          } else {
        console.log("not done");
          }
        } catch (error) {
          console.log(error);
        }
      };
    
    return (
        <>
            {/* Register Start */}
            <div className="container-fluid bg-light overflow-hidden px-lg-0">
                <div className="container contact px-lg-0">
                    <div className="row g-0 mx-lg-0">
                        <div className="col-lg-6 contact-text py-5 wow fadeIn" data-wow-delay="0.5s">
                            <div className="p-lg-5 ps-lg-0">
                                <div className="section-title text-start">
                                    <h1 className="display-5 mb-4">Register</h1>
                                </div>

                                <form>
                                    <div className="row g-3">
                                        <div className="col-md-6">
                                            <div className="form-floating">
                                                <input type="text" className="form-control" id="name" onChange={onValueChange} name='name' placeholder="Your Name" />
                                                <label htmlFor="name">Your Name</label>
                                            </div>
                                        </div>
                                        <div className="col-md-6">
                                            <div className="form-floating">
                                                <input type="email" className="form-control" id="email" onChange={onValueChange} name='email' placeholder="Your Email" />
                                                <label htmlFor="email">Your Email</label>
                                            </div>
                                        </div>
                                        <div className="col-12">
                                            <div className="form-floating">
                                                <input type="password" className="form-control" id="Password" onChange={onValueChange} name='password' placeholder="Password" />
                                                <label htmlFor="subject">Password</label>
                                            </div>
                                        </div>
                                        <div className="col-12">
                                            <div className="form-floating">
                                                <input type="password" className="form-control" onChange={ onValueChange } name='ConPassword' placeholder="Confirm Password" id="ConPassword" />
                                                <label htmlFor="message">Confirm Password</label>
                                            </div>
                                        </div>
                                        <div className="col-12">
                                            <Link to="/Login">Already have an account</Link>
                                        </div>
                                        <div className="col-12">
                                            <button className="btn btn-primary w-100 py-3" type="submit" onClick={submitData} >Register</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div className="col-lg-6 pe-lg-0" style={{ minHeight: "400px" }}>
                            <div className="position-relative h-100">
                                <img className="position-absolute w-100 h-100" style={{ objectFit: "cover" }} src={Carousel1} alt="imgnotfound" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* Register End */}
        </>
    );
}

export default Register;

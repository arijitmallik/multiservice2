import react from 'react';
import ReactDOM from 'react-dom';
import SliderComponent from './SliderComponent';
import Service from './Service';


const Home=()=>{
    return(
    <>
    <SliderComponent/>
    <Service/>

    </>
  );
}

export default Home;

const { MongoClient } = require('mongodb');

// Connection URI
const uri = 'mongodb+srv://arijitmalik469:<password>@cluster0.cfk09sy.mongodb.net/';

// Database and collection names
const dbName = 'bike_service';
const collectionName = 'Bike';

// Create a new MongoClient
const client = new MongoClient(uri);

// Connect to the MongoDB server
client.connect((err) => {
  if (err) {
    console.error('Failed to connect to the database:', err);
    return;
  }

  console.log('Connected successfully to the database');

  // Get a reference to the database
  const db = client.db(dbName);

  // Get a reference to the collection
  const collection = db.collection(collectionName);

  // Query the collection to retrieve data
  collection.find({}).toArray((err, documents) => {
    if (err) {
      console.error('Failed to retrieve data:', err);
      return;
    }

    console.log('Retrieved data:', documents);

    // Close the connection
    client.close();
  });
});

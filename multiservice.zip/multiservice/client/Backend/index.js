const express = require('express');
const path= require('path');
const app= express();
const port=8000;
app.get("",(req,resp)=>{
    resp.send("hey ,welcome ,you are in home page");
});

app.get("/About",(req,resp)=>{
    resp.send("/About");
});

app.get("/Contact",(req,resp)=>{
    resp.send("Contact");
});
app.get("/Login",(req,resp)=>{
    resp.send("/Login");
});
app.get("/Register",(req,resp)=>{
    resp.send("/Register");
});
app.get("/Team",(req,resp)=>{
    resp.send("/Team");
});
app.get("/Service",(req,resp)=>{
    resp.send("/Service");
});

app.get("/ServiceRegister",(req,resp)=>{
    resp.send("/ServiceRegister");
});
